from flask import Flask, render_template, request, redirect, url_for
import os
import pandas as pd
from inventory_backend import InventoryForecast

app = Flask(__name__)

# CSV path based on attached assets
CSV_PATH = "attached_assets/AISupplyChainProject(Sheet1)_1771129264461.csv"
backend = InventoryForecast(CSV_PATH)

def refresh_data():
    """Helper to ensure backend data is processed."""
    backend.load_and_clean_data()
    backend.forecast_demand()
    if backend.output_df is None:
        backend.generate_all_insights()
        backend.export_results()

@app.route('/')
def index():
    refresh_data()
    results = backend.output_df
    
    # Identify critical actions for the Home page
    reorder_alerts = results[results['Reorder_Suggested'] > 0].to_dict('records')
    stockout_alerts = results[results['Stockout_Risk'] < 0].to_dict('records')
    
    return render_template('index.html', reorder_alerts=reorder_alerts, stockout_alerts=stockout_alerts)

@app.route('/forecasts')
def forecasts():
    refresh_data()
    products_data = backend.df.groupby('Product').last().reset_index().to_dict('records')
    return render_template('forecasts.html', products=products_data)

@app.route('/insights')
def insights():
    refresh_data()
    results = backend.output_df.to_dict('records')
    return render_template('insights.html', results=results)

@app.route('/visualizations')
def visualizations():
    refresh_data()
    products = backend.df['Product'].unique()
    # Generate/ensure charts exist for visual grid
    charts = []
    for prod in products[:8]: # Show top 8 for UI balance
        filename = f"{prod.replace(' ', '_')}.png"
        backend.create_plot(prod)
        charts.append(filename)
    
    return render_template('visualizations.html', charts=charts)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
